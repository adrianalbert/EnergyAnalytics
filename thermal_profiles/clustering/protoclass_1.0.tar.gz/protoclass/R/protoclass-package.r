#' protoclass
#'
#' @name protoclass
#' @docType package
NULL
